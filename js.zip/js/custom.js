document.addEventListener("DOMContentLoaded", function () {
    // Search box 
    const searchToggle = document.getElementById("search-toggle");
    const searchBox = document.querySelector(".search-box");
    const navMenu = document.getElementById("navmenu");
    const closeSearch = document.querySelector(".close-search");

    if (searchToggle && searchBox && navMenu && closeSearch) {
        searchToggle.addEventListener("click", function () {
            searchBox.style.display = "block"; // Show search box
            navMenu.style.display = "none"; // Hide nav menu
        });

        closeSearch.addEventListener("click", function () {
            searchBox.style.display = "none"; // Hide search box
            navMenu.style.display = "block"; // Show nav menu
        });
    }
// Product Gallery thumb Swiper Slider
    let productThumbs = new Swiper(".product-gallery-thumbs .thumbnail-wrapper", {
        slidesPerView: 8,
        spaceBetween: 10,
        loop: false,
        breakpoints: {
          768: {
            slidesPerView: 4, 
          },
          480: {
            slidesPerView: 2, 
          },
        },
    });
    // Product Gallery Swiper Slider
    let productSlider = new Swiper(".product-gallery-slider", {
        slidesPerView: 1,
        centeredSlides: true,
        loop: true,
        navigation: {
            nextEl: ".product-gallery-next",
            prevEl: ".product-gallery-prev",
        },
        pagination: {
            el: ".product-gallery-pagination",
            clickable: true,
        },
        thumbs: {
            swiper: productThumbs,
        },
    });
    // As Seen In Swiper Slider
    var swiper = new Swiper(".as-seen-in .init-swiper",  {
        "loop": false,
        "speed": 600,
        "autoplay": {
          "delay": 5000
        },
        "slidesPerView": "auto",
        "pagination": {
          "el": ".swiper-pagination",
          "type": "bullets",
          "clickable": true
        },
        "breakpoints": {
          "320": {
            "slidesPerView": 2,
            "spaceBetween": 40
          },
          "480": {
            "slidesPerView": 3,
            "spaceBetween": 60
          },
          "640": {
            "slidesPerView": 4,
            "spaceBetween": 80
          },
          "992": {
            "slidesPerView": 5,
            "spaceBetween": 120
          }
        }
      });
    // Testimonial Swiper Slider
    var swiper = new Swiper(".testimonials .init-swiper", {
        loop: true,
        speed: 600,
        autoplay: {
            delay: 5000
        },
        centeredSlides: true, 
        slidesPerView: "auto",
        pagination: {
            el: ".swiper-pagination",
            clickable: true
        },
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev"
        },
        breakpoints: {
            320: { slidesPerView: 1, spaceBetween: 40 },
            1200: { slidesPerView: 3, spaceBetween: 20 }
        },
        on: {
            init: function () {
                document.querySelectorAll(".swiper-slide").forEach(slide => {
                    slide.style.opacity = "1";
                    slide.style.filter = "none";
                });
            }
        }
    });
    // Add to Cart Button Update and Click Event
    const flavorOptions = document.querySelectorAll('input[name="flavor"]');
    const purchaseOptions = document.querySelectorAll('input[name="subscription"]');
    const addToCartButton = document.getElementById("add-to-cart");

    function updateCartLink() {
        const selectedFlavor = document.querySelector('input[name="flavor"]:checked')?.value;
        const selectedPurchase = document.querySelector('input[name="subscription"]:checked')?.value;

        if (selectedFlavor && selectedPurchase) {
            const newCartUrl = `https://example.com/cart?flavor=${selectedFlavor}&subscription=${selectedPurchase}`;
            addToCartButton.setAttribute("href", newCartUrl);
            addToCartButton.dataset.flavor = selectedFlavor;
            addToCartButton.dataset.purchase = selectedPurchase;
        }
    }
    // Click Event for Add to Cart
    addToCartButton.addEventListener("click", function (event) {
        event.preventDefault(); // Prevent page refresh or navigation
        const selectedFlavor = addToCartButton.dataset.flavor;
        const selectedPurchase = addToCartButton.dataset.purchase;

        if (selectedFlavor && selectedPurchase) {
            alert(`Product added to cart!\nFlavor: ${selectedFlavor} | subscription Type: ${selectedPurchase}`);
        } else {
            alert("Please select both a flavor and subscription type.");
        }
    });
    flavorOptions.forEach(option => option.addEventListener("change", updateCartLink));
    purchaseOptions.forEach(option => option.addEventListener("change", updateCartLink));
    updateCartLink();
  });
